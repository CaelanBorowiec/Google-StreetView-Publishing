    var streetView;
    var co = 0; //compassOffset

    function initialize() {
    	var streetViewOptions = {
    		pano: "meetingroom_before_pumproom", //Name of the viewpoint to load by default
    		// View angle options: So the viewpoint doesn't load facing a wall
			pov: {
    			heading: 20,
    			pitch: -15,
    			zoom: 1
    		},
    		visible: true,
    		//zoomControl: false,
    		//scrollwheel: false,
    		panoProvider: getCustomPanorama
    	}

    	// Create a StreetView object.
    	var streetViewDiv = document.getElementById('pano_canvas');  //Places the StreetView in the element with the id "pano_canvas"
    	streetView = new google.maps.StreetViewPanorama(streetViewDiv, streetViewOptions);

    	// Add links when "links_change" event fires.
    	google.maps.event.addListener(streetView, "links_changed", createCustomLink);

    	// Create a StreetViewService object.
    	var streetviewService = new google.maps.StreetViewService();
    }

    // Returns a link to the selected tile
    function getCustomPanoramaTileUrl(pano, zoom, tileX, tileY) {
    	var path = "tiles/" + pano + '/zoom' + zoom + '/tile_' + tileY + '_' + tileX + '.JPEG';
    	//console.log(path); //debug
    	return path;
    }

    // Data for the tiles and total image for each viewpoint
    function getCustomPanorama(pano, zoom, tileX, tileY) {
    	switch (pano) {
		
    	case "meetingroom_before_pumproom":
    		return {
    			location: {
    				pano: "meetingroom_before_pumproom",
    				//description: "LevyLab - 3965 O'Hara Street, Pittsburgh, Pennsylvania, United States",
    				latLng: new google.maps.LatLng(40.4442389, -079.9584278)
    			},
    			// The text for the copyright control.
    			copyright: "Imagery &copy;2013 Caelan Borowiec, LevyLab",
    			// The definition of the tiles for this panorama.
    			tiles: {
    				tileSize: new google.maps.Size(1079, 512),
    				worldSize: new google.maps.Size(17264, 8192),
    				// The heading at the origin of the panorama tile set.
    				centerHeading: co + 5,
    				//adjust this
    				getTileUrl: getCustomPanoramaTileUrl
    			}
    		};
    		break;


    	case "meetingroom_past_pumproom":
    		return {
    			location: {
    				pano: "meetingroom_past_pumproom",
    				//description: "LevyLab - 3965 O'Hara Street, Pittsburgh, Pennsylvania, United States",
    				latLng: new google.maps.LatLng(40.4442389, -079.9584278)
    			},
    			// The text for the copyright control.
    			copyright: "Imagery &copy;2013 Caelan Borowiec, LevyLab",
    			// The definition of the tiles for this panorama.
    			tiles: {
    				tileSize: new google.maps.Size(1079, 512),
    				worldSize: new google.maps.Size(17264, 8192),
    				// The heading at the origin of the panorama tile set.
    				centerHeading: co + 5,
    				//adjust this
    				getTileUrl: getCustomPanoramaTileUrl
    			}
    		};
    		break;


    	case "meetingroom_pumproom_door":
    		return {
    			location: {
    				pano: "meetingroom_pumproom_door",
    				//description: "LevyLab - 3965 O'Hara Street, Pittsburgh, Pennsylvania, United States",
    				latLng: new google.maps.LatLng(40.4442389, -079.9584278)
    			},
    			// The text for the copyright control.
    			copyright: "Imagery &copy;2013 Caelan Borowiec, LevyLab",
    			// The definition of the tiles for this panorama.
    			tiles: {
    				tileSize: new google.maps.Size(1079, 512),
    				worldSize: new google.maps.Size(17264, 8192),
    				// The heading at the origin of the panorama tile set.
    				centerHeading: co + 7,
    				//adjust this
    				getTileUrl: getCustomPanoramaTileUrl
    			}
    		};
    		break;


    	case "pump_room":
    		return {
    			location: {
    				pano: "pump_room",
    				//description: "LevyLab - 3965 O'Hara Street, Pittsburgh, Pennsylvania, United States",
    				latLng: new google.maps.LatLng(40.4442389, -079.9584278)
    			},
    			// The text for the copyright control.
    			copyright: "Imagery &copy;2013 Caelan Borowiec, LevyLab",
    			// The definition of the tiles for this panorama.
    			tiles: {
    				tileSize: new google.maps.Size(1080, 512),
    				worldSize: new google.maps.Size(17280, 8192),
    				// The heading at the origin of the panorama tile set.
    				centerHeading: co + 5,
    				//adjust this
    				getTileUrl: getCustomPanoramaTileUrl
    			}
    		};
    		break;

    	}
    }

    // Data for where navigation arrowheads appear and what they connect to


    function createCustomLink() {
    	/*
    	 * add links
    	 */
    	var links = streetView.getLinks();
    	var panoID = streetView.getPano();

    	switch (panoID) {
    	case "meetingroom_before_pumproom":
    		links.push({
    			//description : "",
    			pano: "meetingroom_pumproom_door",
    			heading: 0
    		});
    		break;

    	case "pump_room":
    		links.push({
    			//description : "",
    			pano: "meetingroom_pumproom_door",
    			heading: 90
    		});
    		break;

    	case "meetingroom_pumproom_door":
    		links.push({
    			//description : "",
    			pano: "meetingroom_past_pumproom",
    			heading: 0
    		}, {
    			//description : "",
    			pano: "meetingroom_before_pumproom",
    			heading: 180
    		}, {
    			//description : "",
    			pano: "pump_room",
    			heading: 270
    		});
    		break;

    	case "meetingroom_past_pumproom":
    		links.push({
    			//description : "",
    			pano: "meetingroom_pumproom_door",
    			heading: 180
    		});
    		break;
    	}
    }

    google.maps.event.addDomListener(window, 'load', initialize);